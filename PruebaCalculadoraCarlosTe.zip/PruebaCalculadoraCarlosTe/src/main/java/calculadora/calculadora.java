/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author Carlitos Te
 */
public class calculadora {
    public static void main (String [] args){
        operaciones operacion1 = new operaciones();
        System.out.println("La suma es          :"+operacion1.suma(6,3));
        System.out.println("La resta es         :"+operacion1.resta(6,3));
        System.out.println("La multiplicación es:"+operacion1.multiplicacion(6,3));
        System.out.println("La división es      :"+operacion1.division(6,3));
        System.out.println("La exponenciación es:"+operacion1.exponenciacion(6,3));
    }
}
