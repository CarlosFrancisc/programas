/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author Carlitos Te
 */
public class operaciones {
    
    public int suma(int a, int b){
        return a+b;
    }
    
    public int resta(int a, int b){
        return a-b;
    }
    
    public int multiplicacion(int a, int b){
        return a*b;
    }
    
    public double division(int a, int b){
        return a/b;
    }
    
    public double exponenciacion(int a, int b){
        return Math.pow(a,b);
    }
}
